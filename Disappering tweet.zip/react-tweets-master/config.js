module.exports = {
  twitter: {
    consumer_key: 'MY_CONSUMER_KEY',
    consumer_secret: 'MY_CONSUMER_SECRET',
    access_token_key: 'MY_ACCESS_TOKEN_KEY',
    access_token_secret: 'MY_ACCESS_TOKEN_SECRET'
  }
}